Android PlaneGame
===================

This is a demo of plane game.

----------
Demo
-------------

豌豆荚下载：[http://www.wandoujia.com/apps/edu.njupt.zhb.planegame](http://www.wandoujia.com/apps/edu.njupt.zhb.planegame)

Demo Pic

![image](https://github.com/nuptboyzhb/newplanegame/blob/master/demo/demo1.gif)


----------


Usage
-------------------


#### <i class="icon-refresh"></i> Step 0

1. Eclipse + ADT
2. git clone this project

#### <i class="icon-refresh"></i> Step 1

import this project.

> **Note:** This project is developed under the [AndroidAnotations](https://github.com/excilys/androidannotations) .Properties->Java Compliler->Annotation Processing . Check in "Enable project specific settings" and "Enable annotation processing". ->Factory Path, add the /complie-libs/androidannotations-3.0.1.jar

#### <i class="icon-refresh"></i> Step 2

Run as android application to enjoy it

----------


License
-------------

Copyright 2014  [Zheng Haibo](https://github.com/nuptboyzhb/)

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
