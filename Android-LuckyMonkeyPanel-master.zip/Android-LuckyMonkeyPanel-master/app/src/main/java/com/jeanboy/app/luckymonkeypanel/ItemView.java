package com.jeanboy.app.luckymonkeypanel;

/**
 * Created by jeanboy on 2017/4/25.
 */

public interface ItemView {

    void setFocus(boolean isFocused);
}
