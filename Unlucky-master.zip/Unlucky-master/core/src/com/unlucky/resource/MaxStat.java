package com.unlucky.resource;

/**
 * Represents a "max" statistic
 *
 * @author Ming Li
 */
public class MaxStat {

    public int stat;

    public MaxStat() {
        stat = 0;
    }

}

