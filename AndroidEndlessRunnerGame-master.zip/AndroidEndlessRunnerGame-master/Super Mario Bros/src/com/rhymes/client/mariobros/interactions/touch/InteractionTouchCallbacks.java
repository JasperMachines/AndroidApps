package com.rhymes.client.mariobros.interactions.touch;

import com.rhymes.client.mariobros.interactions.InteractionCallbacks;

public interface InteractionTouchCallbacks extends InteractionCallbacks{
	public void touch(int x, int y);
}
