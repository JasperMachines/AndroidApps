package com.rhymes.client.mariobros.interactions.collision;

import com.rhymes.client.mariobros.interactions.InteractionCallbacks;

public interface InteractionCollisionCallbacks extends InteractionCallbacks{
	public void onCollision(Collision collision);
}
