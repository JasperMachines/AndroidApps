package com.rhymes.client.mariobros.interactions;

public interface InteractionCallbacks {
	
}
