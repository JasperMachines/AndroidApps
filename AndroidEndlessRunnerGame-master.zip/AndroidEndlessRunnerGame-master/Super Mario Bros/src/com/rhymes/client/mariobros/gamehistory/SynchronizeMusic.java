package com.rhymes.client.mariobros.gamehistory;

public class SynchronizeMusic {
	public void wakeUP()
	{
		notifyAll();
	}
}
