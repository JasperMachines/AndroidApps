package com.rhymes.client.mariobros.gamehistory;


public class GameHistory {

	public int  id,highScore;

	
public GameHistory(int iD, int hsc) {
	id = iD;	
	highScore = hsc;
	}
}
