package com.rhymes.client.mariobros.interactions.controller;

import com.rhymes.client.mariobros.interactions.InteractionCallbacks;

public interface InteractionControllerCallbacks extends InteractionCallbacks{
	public void onEvent(int event);
}
