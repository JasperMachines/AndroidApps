AndroidEndlessRunnerGame
========================

Android Endless Runner Game like temple runner using only android canvas and view
GooglePlay Link https://play.google.com/store/apps/details?id=com.rhymes.client.gp.pigshotclone
