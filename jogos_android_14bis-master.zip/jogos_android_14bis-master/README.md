
jogos_android_14bis
===================

Jogo 14 bis para Android criado no livro Desenvolvimento de Jogos para Android com Cocos2D:

http://www.casadocodigo.com.br/products/livro-jogos-android

Você pode baixar o projeto completo, mas indicamos fortemente tentar seguir os passos e explicações do livro. 

As imagens, sons e outros arquivos podem ser baixados aqui também. Para isso, pegue o arquivo no diretório assets.
