package br.com.casadocodigo.bis.game.calibrate;

public interface AccelerometerDelegate {
	public void accelerometerDidAccelerate(float x , float y);
}
