package br.com.casadocodigo.bis.game.control;

public interface ButtonDelegate {
	
	public void buttonClicked(Button sender);
	
}
