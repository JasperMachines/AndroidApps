package br.com.casadocodigo.bis.screens;

import org.cocos2d.nodes.CCSprite;

public class ScreenBackground extends CCSprite {

	public ScreenBackground(String image) {
		super(image);
	}
}
