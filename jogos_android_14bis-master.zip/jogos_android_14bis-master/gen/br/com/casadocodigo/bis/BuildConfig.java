/** Automatically generated file. DO NOT MODIFY */
package br.com.casadocodigo.bis;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}