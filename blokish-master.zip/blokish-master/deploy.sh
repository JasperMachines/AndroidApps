
./gradlew --daemon installDebug

adb shell am start -n org.scoutant.blokish/org.scoutant.blokish.UI
