package de.sopa.model.game;

/**
 * David Schilling - davejs92@gmail.com.
 */
public enum PathState {

    UNDEFINED,
    POSSIBLE,
    IMPOSSIBLE
}
