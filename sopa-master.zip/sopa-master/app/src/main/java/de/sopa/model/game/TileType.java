package de.sopa.model.game;

/**
 * @author  David Schilling - davejs92@gmail.com
 */
public enum TileType {

    START,
    FINISH,
    PUZZLE,
    NONE,
    UNDEFINED
}
