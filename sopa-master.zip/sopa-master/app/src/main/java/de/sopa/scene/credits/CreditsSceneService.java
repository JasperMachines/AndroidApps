package de.sopa.scene.credits;

import de.sopa.manager.BaseSceneService;


/**
 * David Schilling - davejs92@gmail.com.
 */
public interface CreditsSceneService extends BaseSceneService {
}
