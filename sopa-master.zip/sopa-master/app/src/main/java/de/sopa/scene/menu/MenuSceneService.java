package de.sopa.scene.menu;

import de.sopa.manager.BaseSceneService;


/**
 * David Schilling - davejs92@gmail.com.
 */
public interface MenuSceneService extends BaseSceneService {

    void startSynchron();
}
