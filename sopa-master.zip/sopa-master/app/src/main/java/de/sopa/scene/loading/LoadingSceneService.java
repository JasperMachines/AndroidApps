package de.sopa.scene.loading;

import de.sopa.manager.BaseSceneService;


/**
 * David Schilling - davejs92@gmail.com.
 */
public interface LoadingSceneService extends BaseSceneService {

    void initialStart();
}
