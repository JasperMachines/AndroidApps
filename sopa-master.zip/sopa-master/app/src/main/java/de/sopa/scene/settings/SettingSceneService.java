package de.sopa.scene.settings;

import de.sopa.manager.BaseSceneService;


/**
 * David Schilling - davejs92@gmail.com.
 */
public interface SettingSceneService extends BaseSceneService {
}
