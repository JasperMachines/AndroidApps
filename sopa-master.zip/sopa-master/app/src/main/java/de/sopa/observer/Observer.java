package de.sopa.observer;

/**
 * @author  David Schilling - davejs92@gmail.com
 */
public interface Observer {

    void update();
}
