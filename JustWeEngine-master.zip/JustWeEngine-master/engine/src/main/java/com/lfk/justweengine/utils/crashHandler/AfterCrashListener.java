package com.lfk.justweengine.utils.crashHandler;

/**
 * AfterCrashListener
 * save info after crash
 *
 * @author liufengkai
 *         Created by liufengkai on 16/1/17.
 */
public interface AfterCrashListener {
    void AfterCrash();
}
