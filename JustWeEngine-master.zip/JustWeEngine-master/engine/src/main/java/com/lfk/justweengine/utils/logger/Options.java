package com.lfk.justweengine.utils.logger;

/**
 * @author Kale
 * @date 2016/3/25
 */
public enum Options {
    SILENT, FILE, BYTES, COUNT, FORMAT, CLEAR, DUMP
}
