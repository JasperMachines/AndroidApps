package com.lfk.justweengine.drawable.Button;

/**
 * Created by liufengkai on 15/12/10.
 */
public interface OnClickListener {
    void onClick();
}
