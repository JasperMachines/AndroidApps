package com.lfk.justweengine.drawable.Sprite;

/**
 * Created by liufengkai on 15/12/4.
 */
public enum FrameType {
    // fixed frame
    FIXED,
    // frame with rect from a bitmap
    COMMON,
    // only one frame
    SIMPLE
}
