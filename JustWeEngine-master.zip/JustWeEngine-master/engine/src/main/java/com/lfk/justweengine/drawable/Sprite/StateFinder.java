package com.lfk.justweengine.drawable.Sprite;

/**
 * Created by liufengkai on 16/1/15.
 */
public interface StateFinder {
    boolean isContent(BaseSub baseSub);
}
