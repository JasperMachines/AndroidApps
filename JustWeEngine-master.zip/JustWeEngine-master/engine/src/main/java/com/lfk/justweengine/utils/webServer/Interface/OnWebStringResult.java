package com.lfk.justweengine.utils.webServer.Interface;

/**
 * OnWebStringResult easy method for return string
 *
 * @author liufengkai
 *         Created by liufengkai on 16/1/14.
 */
public interface OnWebStringResult extends OnWebResult {
    String OnResult();
}
