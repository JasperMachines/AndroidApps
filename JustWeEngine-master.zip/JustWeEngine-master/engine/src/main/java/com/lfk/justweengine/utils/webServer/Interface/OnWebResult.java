package com.lfk.justweengine.utils.webServer.Interface;

/**
 * OnWebResult empty interface for result
 *
 * @author liufengkai
 *         Created by liufengkai on 16/1/6.
 */
public interface OnWebResult {

}
