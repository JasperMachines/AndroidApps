package com.lfk.justweengine.anim;

/**
 * Created by liufengkai on 15/12/2.
 */
public interface DoAfterAnimation {
    void afterAnimation();
}
