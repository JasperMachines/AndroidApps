package yio.tro.antiyoy.gameplay.editor;

public enum LeInputMode {

    move,

    set_hex,

    set_object,

    delete,

}
