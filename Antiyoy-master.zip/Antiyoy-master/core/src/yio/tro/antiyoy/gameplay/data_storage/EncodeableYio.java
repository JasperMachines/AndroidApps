package yio.tro.antiyoy.gameplay.data_storage;

public interface EncodeableYio {


    String encode();


    void decode(String source);

}
