package yio.tro.antiyoy.gameplay;

public class Obj {

    public static final int PINE = 1;
    public static final int PALM = 2;
    public static final int TOWN = 3;
    public static final int TOWER = 4;
    public static final int GRAVE = 5;
    public static final int FARM = 6;
    public static final int STRONG_TOWER = 7;

}
