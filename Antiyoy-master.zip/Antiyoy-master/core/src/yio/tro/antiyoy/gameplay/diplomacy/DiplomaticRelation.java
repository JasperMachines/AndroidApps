package yio.tro.antiyoy.gameplay.diplomacy;

public class DiplomaticRelation {

    public static final int NEUTRAL = 0;
    public static final int FRIEND = 1;
    public static final int ENEMY = 2;

}
