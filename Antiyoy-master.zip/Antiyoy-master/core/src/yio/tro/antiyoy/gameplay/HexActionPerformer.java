package yio.tro.antiyoy.gameplay;


public interface HexActionPerformer {

    void doAction(Hex hex, Hex adjHex);
}
