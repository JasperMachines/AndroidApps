package yio.tro.antiyoy.gameplay;

public interface SavableYio {


    String saveToString();


    void loadFromString(String src);
}
