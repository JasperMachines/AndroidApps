package yio.tro.antiyoy.gameplay;

public class SelectionTipType {

    public static final int TOWER = 0;
    public static final int UNIT_1 = 1;
    public static final int UNIT_2 = 2;
    public static final int UNIT_3 = 3;
    public static final int UNIT_4 = 4;
    public static final int FARM = 5;
    public static final int STRONG_TOWER = 6;
    public static final int TREE = 7;

}
