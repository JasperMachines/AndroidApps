package yio.tro.antiyoy.gameplay;

public class DebugFlags {

    public static int testWinner = -1;
    public static boolean showFpsInfo = false;
    public static boolean unlockLevels = false;
    public static boolean showFocusedHexInConsole = false;
    public static boolean cheatsEnabled = false;
    public static boolean cheatCharisma = false;
    public static boolean testMode = false;
    public static boolean renderDebug = false;
    public static boolean showSliderBorder = false;
    public static boolean forceKeys = false;


}
