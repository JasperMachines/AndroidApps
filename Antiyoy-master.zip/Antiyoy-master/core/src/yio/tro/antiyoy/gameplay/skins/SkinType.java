package yio.tro.antiyoy.gameplay.skins;

public enum SkinType {

    original,

    points,

    grid,

    shroomarts,

    bubbles,

    jannes_peters,

}
