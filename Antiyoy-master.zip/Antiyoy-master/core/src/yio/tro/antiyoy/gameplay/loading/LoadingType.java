package yio.tro.antiyoy.gameplay.loading;

public enum LoadingType {

    tutorial,

    skirmish,

    campaign_custom_legacy,

    load_game,

    editor_load,

    editor_play,

    campaign_random,

    editor_new,

    load_replay,

    user_level_legacy,

    user_level,

    editor_import,

    campaign_custom,

}
