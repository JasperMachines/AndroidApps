package yio.tro.antiyoy;

import com.badlogic.gdx.Input;

/**
 * Created by yiotro on 19.08.2015.
 */
public class YioTextInputListener implements Input.TextInputListener {

    @Override
    public void input(String text) {

    }


    @Override
    public void canceled() {

    }
}
