package yio.tro.antiyoy.menu;

public enum Animation {

    def,

    up,

    down,

    none,

    from_center,

    fixed_down,

    fixed_up,

    left,

}
