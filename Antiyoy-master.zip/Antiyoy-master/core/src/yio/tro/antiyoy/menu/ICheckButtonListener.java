package yio.tro.antiyoy.menu;

public interface ICheckButtonListener {

    void onStateChanged(boolean checked);

}
