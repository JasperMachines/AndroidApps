package yio.tro.antiyoy.menu.behaviors;

import yio.tro.antiyoy.menu.ButtonYio;

/**
 * Created by yiotro on 01.03.2015.
 */
public class RbNothing extends Reaction {

    @Override
    public void perform(ButtonYio buttonYio) {
        // nothing
    }
}
