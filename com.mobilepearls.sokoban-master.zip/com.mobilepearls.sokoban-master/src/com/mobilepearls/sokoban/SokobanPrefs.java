package com.mobilepearls.sokoban;

public class SokobanPrefs {

	public static final String SHARED_PREFS_NAME = "game_prefs";

}
